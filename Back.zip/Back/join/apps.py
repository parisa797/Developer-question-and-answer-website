from django.apps import AppConfig


class JoinConfig(AppConfig):
    name = 'join'
