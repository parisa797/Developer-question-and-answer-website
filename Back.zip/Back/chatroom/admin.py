from django.contrib import admin
from .models import Chatroom

admin.site.register(Chatroom)
