from django.apps import AppConfig


class GeneralchatroomConfig(AppConfig):
    name = 'generalchatroom'
