import React, { Component } from 'react';
import './CSS/profileTwo.css';


class ProfileTwo extends Component {
    state = {  }
    render() { 
        return ( 
            <React.Fragment>
        
               <div class="parisa-css activity">
                     
               <div class="content-form1 d-flex justify-content-center d-flex align-items-center">
                    
                        <div class="INPUT-FORM2"> 
                        
                            <p> ask questions : 43</p><br></br>
                            <p> answer questions  : 2</p><br></br>
                            <p> activity time : 65h 33 min 23sc</p><br></br>
                            <p> user rate : 1568 </p><br></br>
                            
            
                            </div>
                            
                            
                            
                            </div>
                    </div> 
                
                
            </React.Fragment>
            
         );
    }
}
 
export default ProfileTwo;