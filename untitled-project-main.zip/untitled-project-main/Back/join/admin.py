from django.contrib import admin
from .models import Chatroom_User

admin.site.register(Chatroom_User)
