from django.apps import AppConfig


class SubmittextConfig(AppConfig):
    name = 'submittext'
